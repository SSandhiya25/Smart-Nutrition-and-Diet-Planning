
  # Smart Nutrition & Diet Planner

  This is a code bundle for Smart Nutrition & Diet Planner. The original project is available at https://www.figma.com/design/64mwWP0W9NWOWw2a57Y6xd/Smart-Nutrition---Diet-Planner.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  