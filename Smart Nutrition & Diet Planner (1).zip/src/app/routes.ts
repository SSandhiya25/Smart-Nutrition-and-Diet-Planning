import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { NutritionBasics } from "./pages/NutritionBasics";
import { DietPlans } from "./pages/DietPlans";
import { Calculator } from "./pages/Calculator";
import { Recipes } from "./pages/Recipes";
import { Contact } from "./pages/Contact";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "nutrition-basics", Component: NutritionBasics },
      { path: "diet-plans", Component: DietPlans },
      { path: "calculator", Component: Calculator },
      { path: "recipes", Component: Recipes },
      { path: "contact", Component: Contact },
    ],
  },
]);
