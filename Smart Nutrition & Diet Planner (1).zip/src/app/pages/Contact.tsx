import { Mail, Phone, MapPin, MessageCircle, Lightbulb, Heart, Activity, Apple } from "lucide-react";

export function Contact() {
  const expertTips = [
    {
      icon: <Activity className="w-6 h-6" />,
      title: "Start Small, Stay Consistent",
      tip: "Don't try to change everything at once. Pick one or two healthy habits to focus on each week. Small, consistent changes lead to lasting results.",
      expert: "Dr. Sarah Johnson, Nutritionist",
    },
    {
      icon: <Apple className="w-6 h-6" />,
      title: "Eat the Rainbow",
      tip: "Different colored fruits and vegetables provide different nutrients. Aim to include a variety of colors in your meals throughout the day for optimal nutrition.",
      expert: "Chef Michael Chen, Culinary Nutritionist",
    },
    {
      icon: <Heart className="w-6 h-6" />,
      title: "Listen to Your Body",
      tip: "Pay attention to hunger and fullness cues. Eat when you're hungry, stop when you're satisfied. This intuitive approach promotes a healthy relationship with food.",
      expert: "Dr. Emily Rodriguez, Wellness Coach",
    },
    {
      icon: <Lightbulb className="w-6 h-6" />,
      title: "Meal Prep for Success",
      tip: "Dedicate 2-3 hours on Sunday to prepare healthy meals for the week. Having nutritious options ready makes it easier to stick to your health goals.",
      expert: "Lisa Thompson, Dietitian",
    },
  ];

  const additionalTips = [
    {
      category: "Hydration",
      tips: [
        "Start your day with a glass of water",
        "Keep a water bottle visible throughout the day",
        "Drink water before meals to aid digestion",
        "Herbal teas count towards daily water intake",
      ],
    },
    {
      category: "Mindful Eating",
      tips: [
        "Put away devices during meals",
        "Chew food thoroughly and eat slowly",
        "Use smaller plates for portion control",
        "Stop eating when 80% full (Hara Hachi Bu principle)",
      ],
    },
    {
      category: "Smart Shopping",
      tips: [
        "Shop the perimeter of the grocery store first",
        "Read nutrition labels carefully",
        "Buy seasonal produce for better taste and value",
        "Plan meals before shopping to avoid impulse buys",
      ],
    },
    {
      category: "Sustainable Habits",
      tips: [
        "Allow yourself occasional treats (80/20 rule)",
        "Cook at home more often",
        "Find healthy swaps for favorite foods",
        "Make eating healthy enjoyable, not restrictive",
      ],
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-green-500/10 via-blue-500/10 to-teal-500/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-teal-600 rounded-2xl mb-6">
              <MessageCircle className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl sm:text-5xl mb-6 text-gray-900">
              Contact & Expert Tips
            </h1>
            <p className="text-lg sm:text-xl text-gray-600">
              Get in touch with us and discover proven nutrition tips from health experts
            </p>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl mb-4 text-gray-900">
              Get in Touch
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Have questions about nutrition or need personalized guidance? We're here to help
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-8 text-center">
              <div className="bg-gradient-to-br from-green-500 to-teal-600 w-14 h-14 rounded-xl flex items-center justify-center text-white mx-auto mb-4">
                <Mail className="w-7 h-7" />
              </div>
              <h3 className="text-lg text-gray-900 mb-2">Email Us</h3>
              <p className="text-gray-600">support@smartnutrition.in</p>
              <p className="text-gray-600">info@smartnutrition.in</p>
            </div>

            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-8 text-center">
              <div className="bg-gradient-to-br from-blue-500 to-indigo-600 w-14 h-14 rounded-xl flex items-center justify-center text-white mx-auto mb-4">
                <Phone className="w-7 h-7" />
              </div>
              <h3 className="text-lg text-gray-900 mb-2">Call Us</h3>
              <p className="text-gray-600">+91 91234 56789</p>
              <p className="text-sm text-gray-500 mt-2">Mon-Sat, 9am-6pm IST</p>
            </div>

            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-8 text-center">
              <div className="bg-gradient-to-br from-purple-500 to-pink-600 w-14 h-14 rounded-xl flex items-center justify-center text-white mx-auto mb-4">
                <MapPin className="w-7 h-7" />
              </div>
              <h3 className="text-lg text-gray-900 mb-2">Visit Us</h3>
              <p className="text-gray-600">Health Sciences Building</p>
              <p className="text-gray-600">Chennai, TamilNadu, India</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-16 bg-white/50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-2xl p-8 md:p-12">
            <h2 className="text-2xl sm:text-3xl mb-6 text-gray-900 text-center">
              Send Us a Message
            </h2>

            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-gray-700 mb-2">First Name</label>
                  <input
                    type="text"
                    placeholder="John"
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-green-500 focus:outline-none transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Last Name</label>
                  <input
                    type="text"
                    placeholder="Doe"
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-green-500 focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Email Address</label>
                <input
                  type="email"
                  placeholder="john.doe@example.com"
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-green-500 focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Subject</label>
                <select className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-green-500 focus:outline-none transition-colors">
                  <option>General Inquiry</option>
                  <option>Diet Plan Question</option>
                  <option>Recipe Suggestion</option>
                  <option>Technical Support</option>
                  <option>Other</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Message</label>
                <textarea
                  rows={6}
                  placeholder="Tell us how we can help you..."
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-green-500 focus:outline-none transition-colors resize-none"
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-green-600 to-teal-600 text-white py-4 rounded-xl hover:from-green-700 hover:to-teal-700 transition-all shadow-lg hover:shadow-xl"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Expert Tips Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-14 h-14 bg-gradient-to-br from-green-500 to-teal-600 rounded-xl mb-4">
              <Lightbulb className="w-7 h-7 text-white" />
            </div>
            <h2 className="text-3xl sm:text-4xl mb-4 text-gray-900">
              Expert Tips
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Professional advice from certified nutritionists and wellness experts
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {expertTips.map((item, index) => (
              <div key={index} className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-8">
                <div className="flex items-start gap-4 mb-4">
                  <div className="bg-gradient-to-br from-green-500 to-teal-600 w-12 h-12 rounded-xl flex items-center justify-center text-white flex-shrink-0">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="text-xl text-gray-900 mb-2">{item.title}</h3>
                    <p className="text-gray-600 mb-4">{item.tip}</p>
                    <p className="text-sm text-green-600">— {item.expert}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Additional Tips Grid */}
          <div className="bg-gradient-to-br from-green-50 to-teal-50 rounded-3xl p-8 md:p-12">
            <h3 className="text-2xl text-gray-900 mb-8 text-center">
              Quick Tips for Healthy Living
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {additionalTips.map((section, index) => (
                <div key={index}>
                  <h4 className="text-lg text-gray-900 mb-4 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-green-500"></span>
                    {section.category}
                  </h4>
                  <ul className="space-y-2">
                    {section.tips.map((tip, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                        <span className="text-green-500 mt-1">✓</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Educational Disclaimer */}
      <section className="py-16 bg-white/50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-8 text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full mb-4">
              <span className="text-2xl">📚</span>
            </div>
            <h3 className="text-xl text-gray-900 mb-3">Educational Purpose</h3>
            <p className="text-gray-700 max-w-3xl mx-auto">
              This website is a college health-tech educational project designed to promote awareness 
              about nutrition and healthy living in the Indian context. The information provided is for 
              educational purposes only and should not replace professional medical advice. Always consult 
              with qualified healthcare providers, registered dietitians, or nutritionists for personalized 
              guidance based on your individual health needs and conditions.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}