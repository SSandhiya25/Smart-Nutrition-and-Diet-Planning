import { useState } from "react";
import { Utensils, Clock, Users, Flame, Filter } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

type MealType = "all" | "breakfast" | "lunch" | "dinner" | "snack";

interface Recipe {
  id: number;
  name: string;
  category: MealType;
  image: string;
  prepTime: string;
  servings: number;
  calories: number;
  difficulty: "Easy" | "Medium" | "Hard";
  ingredients: string[];
  instructions: string[];
  nutrition: {
    protein: string;
    carbs: string;
    fats: string;
    fiber: string;
  };
  tags: string[];
}

export function Recipes() {
  const [selectedCategory, setSelectedCategory] = useState<MealType>("all");
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

  const recipes: Recipe[] = [
    {
      id: 1,
      name: "Vegetable Poha",
      category: "breakfast",
      image: "https://images.unsplash.com/photo-1644289450169-bc58aa16bacb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb2hhJTIwaW5kaWFuJTIwYnJlYWtmYXN0fGVufDF8fHx8MTc3MDI3MTM5NXww&ixlib=rb-4.1.0&q=80&w=1080",
      prepTime: "15 min",
      servings: 2,
      calories: 280,
      difficulty: "Easy",
      tags: ["Vegetarian", "Quick", "Popular"],
      ingredients: [
        "2 cups poha (flattened rice)",
        "1 medium onion, chopped",
        "1 medium potato, diced small",
        "1/4 cup peanuts",
        "1 green chilli, chopped",
        "1/2 tsp mustard seeds",
        "1/2 tsp turmeric powder",
        "Few curry leaves",
        "2 tbsp oil",
        "Salt to taste",
        "Fresh coriander for garnish",
        "Lemon juice",
      ],
      instructions: [
        "Rinse poha gently in water and drain immediately. Set aside for 5 minutes",
        "Heat oil in a pan, add mustard seeds and let them splutter",
        "Add peanuts and fry till golden, then add curry leaves and green chilli",
        "Add chopped onions and sauté till translucent",
        "Add diced potatoes, turmeric, and salt. Cover and cook for 5 minutes",
        "Add the soaked poha and mix gently. Cook for 2-3 minutes",
        "Garnish with coriander and lemon juice. Serve hot",
      ],
      nutrition: {
        protein: "8g",
        carbs: "48g",
        fats: "10g",
        fiber: "4g",
      },
    },
    {
      id: 2,
      name: "Idli with Sambar",
      category: "breakfast",
      image: "https://images.unsplash.com/photo-1668236499396-a62d2d1cb0cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpZGxpJTIwc2FtYmFyJTIwc291dGglMjBpbmRpYW58ZW58MXx8fHwxNzcwMTk0NDY5fDA&ixlib=rb-4.1.0&q=80&w=1080",
      prepTime: "20 min",
      servings: 3,
      calories: 250,
      difficulty: "Easy",
      tags: ["Vegetarian", "South Indian", "Healthy"],
      ingredients: [
        "Idli batter (store-bought or homemade)",
        "For Sambar:",
        "1/2 cup toor dal (pigeon pea lentils)",
        "1 cup mixed vegetables (carrots, beans, drumstick)",
        "1 small onion, chopped",
        "1 tomato, chopped",
        "2 tbsp sambar powder",
        "1/2 tsp mustard seeds",
        "Pinch of asafoetida (hing)",
        "Few curry leaves",
        "Tamarind paste - small lemon-sized ball",
        "Salt to taste",
      ],
      instructions: [
        "Grease idli molds and pour batter. Steam for 10-12 minutes until cooked",
        "For sambar: Cook toor dal with turmeric until soft and mushy",
        "In another pan, cook vegetables with water, salt, and turmeric",
        "Add sambar powder and tamarind paste to the cooked vegetables",
        "Add mashed dal to the vegetable mixture and bring to boil",
        "Prepare tempering: heat oil, add mustard seeds, curry leaves, hing",
        "Pour tempering over sambar and simmer for 5 minutes",
        "Serve hot idlis with sambar and coconut chutney",
      ],
      nutrition: {
        protein: "12g",
        carbs: "44g",
        fats: "4g",
        fiber: "6g",
      },
    },
    {
      id: 3,
      name: "Dal-Rice (Comfort Meal)",
      category: "lunch",
      image: "https://images.unsplash.com/photo-1767114915989-c6ab3c8fc42e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYWwlMjByaWNlJTIwaW5kaWFuJTIwbWVhbHxlbnwxfHx8fDE3NzAyNzEzOTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
      prepTime: "30 min",
      servings: 4,
      calories: 380,
      difficulty: "Easy",
      tags: ["Vegetarian", "Comfort Food", "Daily Meal"],
      ingredients: [
        "For Dal:",
        "1 cup toor dal / moong dal",
        "1 tomato, chopped",
        "1 tsp turmeric powder",
        "1 tsp cumin seeds",
        "2-3 garlic cloves",
        "Salt to taste",
        "1 tbsp ghee",
        "For Rice:",
        "1 cup basmati or regular rice",
        "2 cups water",
        "Salt to taste",
      ],
      instructions: [
        "Wash rice and cook with 2 cups water until soft and fluffy",
        "Wash dal and pressure cook with turmeric and salt for 3-4 whistles",
        "Mash the cooked dal slightly with a ladle",
        "Heat ghee in a pan, add cumin seeds and let them crackle",
        "Add chopped garlic and sauté until golden",
        "Add chopped tomatoes and cook until mushy",
        "Pour this tempering over the cooked dal and mix well",
        "Serve hot dal over rice with ghee on top",
      ],
      nutrition: {
        protein: "14g",
        carbs: "62g",
        fats: "6g",
        fiber: "8g",
      },
    },
    {
      id: 4,
      name: "Paneer Bhurji",
      category: "dinner",
      image: "https://images.unsplash.com/photo-1708793873401-e8c6c153b76a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYW5lZXIlMjBjdXJyeSUyMGluZGlhbnxlbnwxfHx8fDE3NzAyNjg0MjN8MA&ixlib=rb-4.1.0&q=80&w=1080",
      prepTime: "20 min",
      servings: 3,
      calories: 320,
      difficulty: "Easy",
      tags: ["Vegetarian", "Protein-Rich", "North Indian"],
      ingredients: [
        "250g paneer (cottage cheese), crumbled",
        "2 medium onions, finely chopped",
        "2 tomatoes, finely chopped",
        "1 green chilli, chopped",
        "1 tsp ginger-garlic paste",
        "1/2 tsp turmeric powder",
        "1/2 tsp red chilli powder",
        "1 tsp coriander powder",
        "1/2 tsp garam masala",
        "2 tbsp oil",
        "Salt to taste",
        "Fresh coriander for garnish",
      ],
      instructions: [
        "Heat oil in a pan, add chopped onions and sauté until golden",
        "Add ginger-garlic paste and green chilli, cook for 1 minute",
        "Add chopped tomatoes and cook until they become soft and mushy",
        "Add all the spice powders (turmeric, chilli, coriander) and salt",
        "Cook the masala for 2-3 minutes until oil separates",
        "Add crumbled paneer and mix well with the masala",
        "Cook for 3-4 minutes, stirring occasionally",
        "Sprinkle garam masala and garnish with coriander",
        "Serve hot with roti or paratha",
      ],
      nutrition: {
        protein: "18g",
        carbs: "16g",
        fats: "22g",
        fiber: "4g",
      },
    },
    {
      id: 5,
      name: "Moong Dal Khichdi",
      category: "dinner",
      image: "https://images.unsplash.com/photo-1630409351211-d62ab2d24da4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxraGljaGRpJTIwaW5kaWFuJTIwY29tZm9ydCUyMGZvb2R8ZW58MXx8fHwxNzcwMjcxMzk2fDA&ixlib=rb-4.1.0&q=80&w=1080",
      prepTime: "25 min",
      servings: 3,
      calories: 310,
      difficulty: "Easy",
      tags: ["Vegetarian", "Easy to Digest", "One-Pot Meal"],
      ingredients: [
        "1/2 cup rice",
        "1/2 cup moong dal (split green gram)",
        "2 cups water",
        "1 medium onion, sliced",
        "1 tomato, chopped",
        "1 tsp cumin seeds",
        "1/2 tsp turmeric powder",
        "1 inch ginger, grated",
        "2 green chillies, slit",
        "Few curry leaves",
        "1 tbsp ghee",
        "Salt to taste",
      ],
      instructions: [
        "Wash rice and moong dal together and soak for 10 minutes",
        "Heat ghee in a pressure cooker, add cumin seeds",
        "Add curry leaves, ginger, and green chillies, sauté briefly",
        "Add sliced onions and cook until soft",
        "Add chopped tomatoes and cook for 2 minutes",
        "Add drained rice-dal mixture, turmeric, and salt",
        "Add 2 cups water and mix well",
        "Pressure cook for 3-4 whistles until soft and mushy",
        "Serve hot with curd, pickle, or papad",
      ],
      nutrition: {
        protein: "12g",
        carbs: "52g",
        fats: "6g",
        fiber: "6g",
      },
    },
    {
      id: 6,
      name: "Mixed Sprouts Salad",
      category: "snack",
      image: "https://images.unsplash.com/photo-1742281258189-3b933879867a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB0aGFsaSUyMG1lYWx8ZW58MXx8fHwxNzcwMjcxMzk3fDA&ixlib=rb-4.1.0&q=80&w=1080",
      prepTime: "10 min",
      servings: 2,
      calories: 150,
      difficulty: "Easy",
      tags: ["Vegetarian", "Protein-Rich", "Low-Calorie"],
      ingredients: [
        "1 cup mixed sprouts (moong, chana, matki)",
        "1 medium onion, finely chopped",
        "1 medium tomato, chopped",
        "1 cucumber, chopped",
        "1 green chilli, finely chopped",
        "1/4 cup fresh coriander, chopped",
        "1 lemon, juiced",
        "1/2 tsp chaat masala",
        "1/4 tsp black salt",
        "Regular salt to taste",
      ],
      instructions: [
        "Boil the sprouts in salted water for 5-7 minutes until tender",
        "Drain and let them cool down",
        "In a large bowl, combine sprouts with chopped onions, tomatoes, and cucumber",
        "Add chopped green chilli and fresh coriander",
        "Squeeze lemon juice over the salad",
        "Sprinkle chaat masala, black salt, and regular salt",
        "Mix everything well and serve immediately",
        "Optional: Add roasted peanuts for extra crunch",
      ],
      nutrition: {
        protein: "10g",
        carbs: "24g",
        fats: "2g",
        fiber: "8g",
      },
    },
  ];

  const filteredRecipes =
    selectedCategory === "all"
      ? recipes
      : recipes.filter((recipe) => recipe.category === selectedCategory);

  const categories = [
    { value: "all" as MealType, label: "All Recipes" },
    { value: "breakfast" as MealType, label: "Breakfast" },
    { value: "lunch" as MealType, label: "Lunch" },
    { value: "dinner" as MealType, label: "Dinner" },
    { value: "snack" as MealType, label: "Snacks" },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-green-500/10 via-blue-500/10 to-teal-500/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-teal-600 rounded-2xl mb-6">
              <Utensils className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl sm:text-5xl mb-6 text-gray-900">
              Healthy Indian Recipes
            </h1>
            <p className="text-lg sm:text-xl text-gray-600">
              Delicious, nutritious Indian recipes that make healthy eating enjoyable and easy
            </p>
          </div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-8 bg-white/80 backdrop-blur-md sticky top-16 z-40 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4 overflow-x-auto pb-2">
            <Filter className="w-5 h-5 text-gray-600 flex-shrink-0" />
            {categories.map((category) => (
              <button
                key={category.value}
                onClick={() => setSelectedCategory(category.value)}
                className={`px-6 py-2 rounded-full whitespace-nowrap transition-all ${
                  selectedCategory === category.value
                    ? "bg-gradient-to-r from-green-600 to-teal-600 text-white shadow-lg"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Recipes Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredRecipes.map((recipe) => (
              <div
                key={recipe.id}
                className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all hover:-translate-y-1 cursor-pointer"
                onClick={() => setSelectedRecipe(recipe)}
              >
                <div className="relative h-48 overflow-hidden">
                  <ImageWithFallback
                    src={recipe.image}
                    alt={recipe.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm text-gray-700">
                    {recipe.difficulty}
                  </div>
                  <div className="absolute bottom-4 left-4 flex flex-wrap gap-2">
                    {recipe.tags.slice(0, 2).map((tag, idx) => (
                      <span key={idx} className="bg-green-500 text-white px-2 py-1 rounded-full text-xs">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-xl mb-3 text-gray-900">{recipe.name}</h3>

                  <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>{recipe.prepTime}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      <span>{recipe.servings} serving{recipe.servings > 1 ? 's' : ''}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Flame className="w-4 h-4" />
                      <span>{recipe.calories} cal</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-2 text-xs">
                    <div className="bg-orange-50 p-2 rounded text-center">
                      <div className="text-orange-600 mb-1">Protein</div>
                      <div className="text-gray-700">{recipe.nutrition.protein}</div>
                    </div>
                    <div className="bg-amber-50 p-2 rounded text-center">
                      <div className="text-amber-600 mb-1">Carbs</div>
                      <div className="text-gray-700">{recipe.nutrition.carbs}</div>
                    </div>
                    <div className="bg-yellow-50 p-2 rounded text-center">
                      <div className="text-yellow-600 mb-1">Fats</div>
                      <div className="text-gray-700">{recipe.nutrition.fats}</div>
                    </div>
                    <div className="bg-green-50 p-2 rounded text-center">
                      <div className="text-green-600 mb-1">Fiber</div>
                      <div className="text-gray-700">{recipe.nutrition.fiber}</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Recipe Modal */}
      {selectedRecipe && (
        <div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedRecipe(null)}
        >
          <div
            className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative h-64">
              <ImageWithFallback
                src={selectedRecipe.image}
                alt={selectedRecipe.name}
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => setSelectedRecipe(null)}
                className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm w-10 h-10 rounded-full flex items-center justify-center hover:bg-white transition-colors"
              >
                ✕
              </button>
              <div className="absolute bottom-4 left-4 flex flex-wrap gap-2">
                {selectedRecipe.tags.map((tag, idx) => (
                  <span key={idx} className="bg-green-500 text-white px-3 py-1 rounded-full text-sm">
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-8">
              <h2 className="text-3xl mb-4 text-gray-900">{selectedRecipe.name}</h2>

              <div className="flex flex-wrap gap-6 text-gray-600 mb-8">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  <span>{selectedRecipe.prepTime}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  <span>{selectedRecipe.servings} serving{selectedRecipe.servings > 1 ? 's' : ''}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Flame className="w-5 h-5" />
                  <span>{selectedRecipe.calories} calories</span>
                </div>
                <div className="bg-green-100 text-green-700 px-4 py-1 rounded-full">
                  {selectedRecipe.difficulty}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                {/* Ingredients */}
                <div>
                  <h3 className="text-xl mb-4 text-gray-900">Ingredients</h3>
                  <ul className="space-y-2">
                    {selectedRecipe.ingredients.map((ingredient, index) => (
                      <li key={index} className="flex items-start gap-2 text-gray-700">
                        {ingredient.endsWith(':') ? (
                          <span className="font-semibold text-green-600">{ingredient}</span>
                        ) : (
                          <>
                            <span className="text-green-500 mt-1">•</span>
                            <span>{ingredient}</span>
                          </>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Nutrition */}
                <div>
                  <h3 className="text-xl mb-4 text-gray-900">Nutrition Per Serving</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                      <span className="text-gray-700">Protein</span>
                      <span className="text-orange-600">{selectedRecipe.nutrition.protein}</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-amber-50 rounded-lg">
                      <span className="text-gray-700">Carbohydrates</span>
                      <span className="text-amber-600">{selectedRecipe.nutrition.carbs}</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                      <span className="text-gray-700">Fats</span>
                      <span className="text-yellow-600">{selectedRecipe.nutrition.fats}</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                      <span className="text-gray-700">Fiber</span>
                      <span className="text-green-600">{selectedRecipe.nutrition.fiber}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Instructions */}
              <div>
                <h3 className="text-xl mb-4 text-gray-900">Instructions</h3>
                <ol className="space-y-4">
                  {selectedRecipe.instructions.map((instruction, index) => (
                    <li key={index} className="flex gap-4">
                      <span className="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-green-500 to-teal-600 text-white rounded-full flex items-center justify-center">
                        {index + 1}
                      </span>
                      <span className="text-gray-700 pt-1">{instruction}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
