import { Apple, Droplets, Wheat, Beef, Zap, Shield, Brain, Activity } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function NutritionBasics() {
  const macronutrients = [
    {
      icon: <Wheat className="w-8 h-8" />,
      name: "Carbohydrates",
      color: "from-amber-500 to-orange-500",
      description: "Primary energy source for your body and brain",
      dailyNeed: "45-65% of total calories",
      sources: ["Rice", "Wheat (roti/chapati)", "Jowar", "Bajra", "Oats", "Fruits"],
      benefits: ["Quick energy", "Brain function", "Fiber for digestion"],
    },
    {
      icon: <Beef className="w-8 h-8" />,
      name: "Proteins",
      color: "from-red-500 to-pink-500",
      description: "Building blocks for muscles, tissues, and enzymes",
      dailyNeed: "10-35% of total calories",
      sources: ["Lean meats", "Fish", "Eggs", "Beans", "Nuts"],
      benefits: ["Muscle repair", "Enzyme production", "Immune function"],
    },
    {
      icon: <Droplets className="w-8 h-8" />,
      name: "Fats",
      color: "from-yellow-500 to-amber-500",
      description: "Essential for hormone production and vitamin absorption",
      dailyNeed: "20-35% of total calories",
      sources: ["Ghee", "Mustard oil", "Nuts", "Seeds", "Fish", "Coconut"],
      benefits: ["Hormone balance", "Vitamin absorption", "Cell structure"],
    },
  ];

  const micronutrients = [
    {
      icon: <Shield className="w-6 h-6" />,
      name: "Vitamins",
      examples: ["Vitamin A (vision)", "Vitamin C (immunity)", "Vitamin D (bones)", "Vitamin E (antioxidant)"],
      color: "bg-green-500",
    },
    {
      icon: <Zap className="w-6 h-6" />,
      name: "Minerals",
      examples: ["Calcium (bones)", "Iron (blood)", "Zinc (immunity)", "Magnesium (muscles)"],
      color: "bg-blue-500",
    },
  ];

  const healthyHabits = [
    {
      icon: <Droplets className="w-6 h-6" />,
      title: "Stay Hydrated",
      description: "Drink 8-10 glasses of water daily",
      tips: ["Start your day with water", "Carry a reusable bottle", "Eat water-rich foods"],
    },
    {
      icon: <Activity className="w-6 h-6" />,
      title: "Balanced Meals",
      description: "Follow the plate method for portion control",
      tips: ["½ plate vegetables", "¼ plate protein", "¼ plate whole grains"],
    },
    {
      icon: <Brain className="w-6 h-6" />,
      title: "Mindful Eating",
      description: "Pay attention to hunger and fullness cues",
      tips: ["Eat slowly", "Minimize distractions", "Listen to your body"],
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-green-500/10 via-blue-500/10 to-teal-500/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-teal-600 rounded-2xl mb-6">
              <Apple className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl sm:text-5xl mb-6 text-gray-900">
              Nutrition Basics
            </h1>
            <p className="text-lg sm:text-xl text-gray-600">
              Understanding the fundamentals of nutrition is the first step toward a healthier lifestyle. 
              Learn about essential nutrients and how they fuel your body with Indian food examples.
            </p>
          </div>
        </div>
      </section>

      {/* Macronutrients Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl mb-4 text-gray-900">
              The Big Three: Macronutrients
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              These nutrients are needed in large amounts and provide energy for your body
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {macronutrients.map((macro, index) => (
              <div key={index} className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg overflow-hidden">
                <div className={`bg-gradient-to-br ${macro.color} p-8 text-white`}>
                  <div className="flex items-center gap-3 mb-4">
                    {macro.icon}
                    <h3 className="text-2xl">{macro.name}</h3>
                  </div>
                  <p className="text-white/90 mb-4">{macro.description}</p>
                  <div className="bg-white/20 backdrop-blur-sm rounded-lg p-3">
                    <div className="text-sm text-white/80 mb-1">Daily Need</div>
                    <div className="text-lg">{macro.dailyNeed}</div>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="mb-4">
                    <h4 className="text-sm text-gray-700 mb-2">Food Sources</h4>
                    <div className="flex flex-wrap gap-2">
                      {macro.sources.map((source, idx) => (
                        <span key={idx} className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                          {source}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm text-gray-700 mb-2">Key Benefits</h4>
                    <ul className="space-y-1">
                      {macro.benefits.map((benefit, idx) => (
                        <li key={idx} className="text-sm text-gray-600 flex items-start gap-2">
                          <span className="text-green-500 mt-1">•</span>
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Micronutrients Section */}
      <section className="py-16 bg-white/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl mb-4 text-gray-900">
              Micronutrients: Small but Mighty
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Needed in smaller amounts but crucial for health and disease prevention
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {micronutrients.map((micro, index) => (
              <div key={index} className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className={`${micro.color} p-3 rounded-xl text-white`}>
                    {micro.icon}
                  </div>
                  <h3 className="text-2xl text-gray-900">{micro.name}</h3>
                </div>
                
                <div className="space-y-2">
                  {micro.examples.map((example, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-gray-600">
                      <span className="text-green-500 mt-1">✓</span>
                      <span>{example}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Visual Guide Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl mb-4 text-gray-900">
              The Balanced Plate
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              A visual guide to building nutritious, well-balanced meals
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1684160244466-b89ef03b7638?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWxhbmNlZCUyMG1lYWwlMjBwbGF0ZXxlbnwxfHx8fDE3NzAyNjk4NTl8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Balanced meal plate"
                className="rounded-2xl shadow-2xl w-full h-[400px] object-cover"
              />
            </div>

            <div className="space-y-6">
              <div className="bg-white/80 backdrop-blur-md rounded-xl p-6 shadow-lg">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-4 h-4 rounded-full bg-green-500"></div>
                  <h4 className="text-lg text-gray-900">Half Your Plate: Vegetables & Fruits</h4>
                </div>
                <p className="text-gray-600">
                  Fill half your plate with colorful vegetables and fruits for vitamins, minerals, and fiber.
                </p>
              </div>

              <div className="bg-white/80 backdrop-blur-md rounded-xl p-6 shadow-lg">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-4 h-4 rounded-full bg-red-500"></div>
                  <h4 className="text-lg text-gray-900">Quarter of Your Plate: Lean Protein</h4>
                </div>
                <p className="text-gray-600">
                  Include lean meats, fish, eggs, beans, or tofu for muscle health and repair.
                </p>
              </div>

              <div className="bg-white/80 backdrop-blur-md rounded-xl p-6 shadow-lg">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-4 h-4 rounded-full bg-amber-500"></div>
                  <h4 className="text-lg text-gray-900">Quarter of Your Plate: Whole Grains</h4>
                </div>
                <p className="text-gray-600">
                  Choose whole grains like brown rice, quinoa, or whole wheat for sustained energy.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Healthy Habits Section */}
      <section className="py-16 bg-white/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl mb-4 text-gray-900">
              Healthy Eating Habits
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Simple practices that make a big difference in your nutrition
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {healthyHabits.map((habit, index) => (
              <div key={index} className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-8">
                <div className="bg-gradient-to-br from-green-500 to-teal-600 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4">
                  {habit.icon}
                </div>
                <h3 className="text-xl mb-2 text-gray-900">{habit.title}</h3>
                <p className="text-gray-600 mb-4">{habit.description}</p>
                <ul className="space-y-2">
                  {habit.tips.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm text-gray-600">
                      <span className="text-green-500 mt-1">•</span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Nutrition Myths vs Facts Section */}
      <section className="py-16 bg-white/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-14 h-14 bg-gradient-to-br from-red-500 to-orange-500 rounded-xl mb-4">
              <span className="text-3xl">⚡</span>
            </div>
            <h2 className="text-3xl sm:text-4xl mb-4 text-gray-900">
              Nutrition Myths vs Facts
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Separating fact from fiction to help you make informed dietary choices
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-8">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-red-100 text-red-600 px-3 py-1 rounded-lg text-sm flex-shrink-0">Myth</div>
                <p className="text-gray-700">"Carbs are bad and should be avoided"</p>
              </div>
              <div className="flex items-start gap-4 pl-4 border-l-4 border-green-500">
                <div className="bg-green-100 text-green-600 px-3 py-1 rounded-lg text-sm flex-shrink-0">Fact</div>
                <p className="text-gray-700">Carbohydrates are essential for energy. Focus on whole grains like brown rice, roti, and oats instead of refined carbs.</p>
              </div>
            </div>

            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-8">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-red-100 text-red-600 px-3 py-1 rounded-lg text-sm flex-shrink-0">Myth</div>
                <p className="text-gray-700">"Eating fat makes you fat"</p>
              </div>
              <div className="flex items-start gap-4 pl-4 border-l-4 border-green-500">
                <div className="bg-green-100 text-green-600 px-3 py-1 rounded-lg text-sm flex-shrink-0">Fact</div>
                <p className="text-gray-700">Healthy fats like ghee, nuts, and fish are vital for hormone balance and vitamin absorption. It's about choosing the right fats.</p>
              </div>
            </div>

            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-8">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-red-100 text-red-600 px-3 py-1 rounded-lg text-sm flex-shrink-0">Myth</div>
                <p className="text-gray-700">"Skipping meals helps in weight loss"</p>
              </div>
              <div className="flex items-start gap-4 pl-4 border-l-4 border-green-500">
                <div className="bg-green-100 text-green-600 px-3 py-1 rounded-lg text-sm flex-shrink-0">Fact</div>
                <p className="text-gray-700">Skipping meals can slow metabolism and lead to overeating later. Eat regular, balanced meals throughout the day.</p>
              </div>
            </div>

            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-8">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-red-100 text-red-600 px-3 py-1 rounded-lg text-sm flex-shrink-0">Myth</div>
                <p className="text-gray-700">"All calories are equal"</p>
              </div>
              <div className="flex items-start gap-4 pl-4 border-l-4 border-green-500">
                <div className="bg-green-100 text-green-600 px-3 py-1 rounded-lg text-sm flex-shrink-0">Fact</div>
                <p className="text-gray-700">Not all calories affect your body the same way. 100 calories from dal is more nutritious than 100 calories from sweets.</p>
              </div>
            </div>

            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-8">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-red-100 text-red-600 px-3 py-1 rounded-lg text-sm flex-shrink-0">Myth</div>
                <p className="text-gray-700">"Eating late at night causes weight gain"</p>
              </div>
              <div className="flex items-start gap-4 pl-4 border-l-4 border-green-500">
                <div className="bg-green-100 text-green-600 px-3 py-1 rounded-lg text-sm flex-shrink-0">Fact</div>
                <p className="text-gray-700">What matters is total daily calorie intake, not timing. However, eating lighter dinners can improve digestion and sleep.</p>
              </div>
            </div>

            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-8">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-red-100 text-red-600 px-3 py-1 rounded-lg text-sm flex-shrink-0">Myth</div>
                <p className="text-gray-700">"Protein is only for bodybuilders"</p>
              </div>
              <div className="flex items-start gap-4 pl-4 border-l-4 border-green-500">
                <div className="bg-green-100 text-green-600 px-3 py-1 rounded-lg text-sm flex-shrink-0">Fact</div>
                <p className="text-gray-700">Everyone needs protein for cell repair, immunity, and overall health. Include dal, paneer, eggs, or fish in your daily diet.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Hydration Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-blue-500 to-cyan-500 rounded-3xl p-12 text-white shadow-2xl">
            <div className="max-w-3xl mx-auto text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl mb-6">
                <Droplets className="w-8 h-8" />
              </div>
              <h2 className="text-3xl sm:text-4xl mb-4">
                Don't Forget Hydration!
              </h2>
              <p className="text-lg text-blue-50 mb-6">
                Water is essential for every function in your body. Aim for 8-10 glasses (2-2.5 liters) per day, 
                more if you're active or in hot weather.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
                  <div className="text-2xl mb-1">60%</div>
                  <div className="text-sm text-blue-50">Body is water</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
                  <div className="text-2xl mb-1">8-10</div>
                  <div className="text-sm text-blue-50">Glasses daily</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
                  <div className="text-2xl mb-1">75%</div>
                  <div className="text-sm text-blue-50">Brain is water</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
                  <div className="text-2xl mb-1">30min</div>
                  <div className="text-sm text-blue-50">Before meals</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}