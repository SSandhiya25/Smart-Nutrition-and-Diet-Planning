import { useState } from "react";
import { GraduationCap, Briefcase, Heart, Clock, Target, CheckCircle2, Leaf } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

type DietPlanType = "student" | "working" | "elderly";
type DietPreference = "veg" | "nonveg";

export function DietPlans() {
  const [selectedPlan, setSelectedPlan] = useState<DietPlanType>("student");
  const [dietPreference, setDietPreference] = useState<DietPreference>("veg");

  const plans = {
    student: {
      title: "Student Diet Plan",
      subtitle: "For ages 18-25",
      icon: <GraduationCap className="w-8 h-8" />,
      color: "from-blue-500 to-indigo-600",
      image: "https://images.unsplash.com/photo-1720022477040-685f8c3a01be?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwc3R1ZHlpbmclMjBoZWFsdGh5JTIwc25hY2tzfGVufDF8fHx8MTc3MDI2OTk0M3ww&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Fuel your brain and body for academic success with balanced, affordable Indian meals",
      calories: "2000-2500 calories/day",
      focus: ["Brain function", "Energy levels", "Budget-friendly", "Quick preparation"],
      meals: {
        veg: {
          breakfast: {
            time: "7:00 - 9:00 AM",
            items: [
              "Poha with peanuts and vegetables (300 cal)",
              "Idli (3) with sambar and chutney (280 cal)",
              "Paratha (2) with curd and pickle (350 cal)",
              "Upma with vegetables and coconut chutney (250 cal)",
            ],
          },
          midMorning: {
            time: "10:30 - 11:00 AM",
            items: [
              "Banana with roasted chana (150 cal)",
              "Sprouts chaat (120 cal)",
              "Fruit salad (small bowl) (100 cal)",
            ],
          },
          lunch: {
            time: "12:30 - 1:30 PM",
            items: [
              "Dal-rice with vegetable sabzi and salad (450 cal)",
              "Rajma-chawal with curd (480 cal)",
              "Chole with 2 roti and onion (420 cal)",
              "Paneer curry with rice and dal (500 cal)",
            ],
          },
          afternoon: {
            time: "4:00 - 5:00 PM",
            items: [
              "Masala chai with biscuits (2-3) (130 cal)",
              "Roasted makhana (fox nuts) (100 cal)",
              "Vegetable sandwich (150 cal)",
            ],
          },
          dinner: {
            time: "7:00 - 8:00 PM",
            items: [
              "Khichdi with curd and papad (380 cal)",
              "Roti (2) with mixed dal and sabzi (400 cal)",
              "Vegetable pulao with raita (420 cal)",
              "Paratha with curd and pickle (380 cal)",
            ],
          },
        },
        nonveg: {
          breakfast: {
            time: "7:00 - 9:00 AM",
            items: [
              "Omelette (2 eggs) with bread toast (2) (320 cal)",
              "Egg bhurji with 2 paratha (380 cal)",
              "Boiled eggs (2) with upma (300 cal)",
              "Bread omelette with chai (280 cal)",
            ],
          },
          midMorning: {
            time: "10:30 - 11:00 AM",
            items: [
              "Boiled egg with fruit (150 cal)",
              "Chicken sandwich (small) (180 cal)",
              "Protein shake with banana (160 cal)",
            ],
          },
          lunch: {
            time: "12:30 - 1:30 PM",
            items: [
              "Chicken curry with rice and salad (500 cal)",
              "Fish fry with dal-rice (480 cal)",
              "Egg curry with 2 roti (420 cal)",
              "Chicken biryani (small portion) with raita (550 cal)",
            ],
          },
          afternoon: {
            time: "4:00 - 5:00 PM",
            items: [
              "Boiled eggs (1) with tea (120 cal)",
              "Chicken roll (small) (180 cal)",
              "Nuts and seeds mix (150 cal)",
            ],
          },
          dinner: {
            time: "7:00 - 8:00 PM",
            items: [
              "Grilled chicken with roti and salad (450 cal)",
              "Fish curry with rice (420 cal)",
              "Egg fried rice with soup (400 cal)",
              "Chicken soup with bread (2 slices) (350 cal)",
            ],
          },
        },
      },
      tips: [
        "Prepare tiffin the night before to save morning time",
        "Keep healthy snacks like roasted chana, nuts in your bag",
        "Avoid excessive junk food and cold drinks",
        "Don't skip breakfast - it fuels your concentration",
        "Drink plenty of water throughout the day",
        "Study better with proper nutrition",
      ],
    },
    working: {
      title: "Working Adult Diet Plan",
      subtitle: "For ages 26-55",
      icon: <Briefcase className="w-8 h-8" />,
      color: "from-green-500 to-teal-600",
      image: "https://images.unsplash.com/photo-1758762641372-e3b52bf061d4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvZmZpY2UlMjB3b3JrZXIlMjBkZXNrJTIwbHVuY2h8ZW58MXx8fHwxNzcwMjY5OTQ0fDA&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Balanced nutrition for busy Indian professionals managing work-life balance",
      calories: "1800-2400 calories/day",
      focus: ["Stress management", "Heart health", "Weight management", "Energy balance"],
      meals: {
        veg: {
          breakfast: {
            time: "6:30 - 8:00 AM",
            items: [
              "Besan chilla (2) with green chutney (280 cal)",
              "Moong dal cheela with curd (300 cal)",
              "Vegetable poha with peanuts (280 cal)",
              "Dalia (broken wheat) with vegetables (260 cal)",
            ],
          },
          midMorning: {
            time: "10:00 - 10:30 AM",
            items: [
              "Green tea with nuts (5-6) (100 cal)",
              "Fruit (apple/orange) (80 cal)",
              "Buttermilk with roasted jeera (60 cal)",
            ],
          },
          lunch: {
            time: "12:30 - 1:30 PM",
            items: [
              "Brown rice with dal, sabzi and salad (400 cal)",
              "2 roti with paneer curry and curd (420 cal)",
              "Vegetable khichdi with curd (380 cal)",
              "Pulao with raita and salad (400 cal)",
            ],
          },
          afternoon: {
            time: "3:30 - 4:00 PM",
            items: [
              "Green tea with Marie biscuits (2) (100 cal)",
              "Roasted chana (handful) (120 cal)",
              "Carrot and cucumber sticks (50 cal)",
            ],
          },
          dinner: {
            time: "7:30 - 8:30 PM",
            items: [
              "Mixed vegetable soup with 1 roti (320 cal)",
              "Dal-rice with stir-fried vegetables (380 cal)",
              "Roti (2) with palak paneer and salad (400 cal)",
              "Vegetable dalia with curd (340 cal)",
            ],
          },
        },
        nonveg: {
          breakfast: {
            time: "6:30 - 8:00 AM",
            items: [
              "Egg white omelette with multigrain bread (280 cal)",
              "Boiled eggs (2) with upma (300 cal)",
              "Egg bhurji with roti (2) (320 cal)",
              "Oats with boiled egg (260 cal)",
            ],
          },
          midMorning: {
            time: "10:00 - 10:30 AM",
            items: [
              "Boiled egg white (2) (80 cal)",
              "Protein shake (120 cal)",
              "Buttermilk (100 cal)",
            ],
          },
          lunch: {
            time: "12:30 - 1:30 PM",
            items: [
              "Grilled chicken with brown rice and salad (420 cal)",
              "Fish curry with rice and vegetables (400 cal)",
              "Chicken salad with whole wheat bread (380 cal)",
              "Egg curry with 2 roti and salad (400 cal)",
            ],
          },
          afternoon: {
            time: "3:30 - 4:00 PM",
            items: [
              "Green tea with almonds (6-7) (120 cal)",
              "Boiled egg (1) (70 cal)",
              "Vegetable soup (80 cal)",
            ],
          },
          dinner: {
            time: "7:30 - 8:30 PM",
            items: [
              "Grilled fish with vegetables and salad (380 cal)",
              "Chicken soup with 1 roti (350 cal)",
              "Tandoori chicken with cucumber salad (400 cal)",
              "Fish tikka with roti and vegetables (420 cal)",
            ],
          },
        },
      },
      tips: [
        "Pack home-cooked lunch to avoid oily restaurant food",
        "Take 5-minute walking breaks every 2 hours",
        "Practice portion control to maintain healthy weight",
        "Reduce salt and sugar intake",
        "Manage stress with yoga and meditation",
        "Avoid late-night snacking and heavy dinners",
      ],
    },
    elderly: {
      title: "Elderly Diet Plan",
      subtitle: "For ages 55+",
      icon: <Heart className="w-8 h-8" />,
      color: "from-purple-500 to-pink-600",
      image: "https://images.unsplash.com/photo-1765200231320-987437f4acc5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGRlcmx5JTIwcGVyc29uJTIwaGVhbHRoeSUyMG1lYWx8ZW58MXx8fHwxNzcwMjY5OTQ0fDA&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Nutrient-dense Indian meals supporting bone health, immunity, and vitality",
      calories: "1600-2000 calories/day",
      focus: ["Bone health", "Heart health", "Digestive health", "Immune support"],
      meals: {
        veg: {
          breakfast: {
            time: "7:00 - 8:30 AM",
            items: [
              "Daliya (broken wheat) porridge with milk (280 cal)",
              "Idli (2) with sambar (250 cal)",
              "Vegetable upma with chutney (260 cal)",
              "Soft dosa with coconut chutney (280 cal)",
            ],
          },
          midMorning: {
            time: "10:00 - 10:30 AM",
            items: [
              "Warm milk with turmeric and dates (2) (150 cal)",
              "Papaya or banana (100 cal)",
              "Herbal tea with digestive biscuits (2) (120 cal)",
            ],
          },
          lunch: {
            time: "12:00 - 1:00 PM",
            items: [
              "Moong dal khichdi with curd and ghee (360 cal)",
              "Soft roti (2) with dal and lauki sabzi (350 cal)",
              "Rice with sambar and vegetable curry (340 cal)",
              "Vegetable daliya with buttermilk (320 cal)",
            ],
          },
          afternoon: {
            time: "3:30 - 4:00 PM",
            items: [
              "Herbal tea with roasted rusk (120 cal)",
              "Banana with almonds (3-4) (140 cal)",
              "Warm milk with jaggery (100 cal)",
            ],
          },
          dinner: {
            time: "6:30 - 7:30 PM",
            items: [
              "Vegetable soup with soft roti (280 cal)",
              "Khichdi with curd and ghee (320 cal)",
              "Soft paratha with curd and pickle (300 cal)",
              "Rice with dal and boiled vegetables (340 cal)",
            ],
          },
        },
        nonveg: {
          breakfast: {
            time: "7:00 - 8:30 AM",
            items: [
              "Soft boiled eggs (2) with bread (280 cal)",
              "Egg khichdi with curd (300 cal)",
              "Omelette (1 egg) with soft roti (260 cal)",
              "Egg porridge with milk (280 cal)",
            ],
          },
          midMorning: {
            time: "10:00 - 10:30 AM",
            items: [
              "Warm milk with almonds soaked (120 cal)",
              "Soft fruits like papaya (80 cal)",
              "Bone broth (100 cal)",
            ],
          },
          lunch: {
            time: "12:00 - 1:00 PM",
            items: [
              "Chicken soup with rice (360 cal)",
              "Soft fish curry with rice (380 cal)",
              "Egg curry with soft roti (2) (350 cal)",
              "Minced chicken with dalia (340 cal)",
            ],
          },
          afternoon: {
            time: "3:30 - 4:00 PM",
            items: [
              "Boiled egg (1) with tea (120 cal)",
              "Chicken broth (80 cal)",
              "Milk with protein powder (140 cal)",
            ],
          },
          dinner: {
            time: "6:30 - 7:30 PM",
            items: [
              "Fish soup with soft bread (300 cal)",
              "Boiled chicken with vegetables (320 cal)",
              "Egg khichdi with curd (340 cal)",
              "Fish curry (mild) with rice (360 cal)",
            ],
          },
        },
      },
      tips: [
        "Focus on calcium-rich foods like milk, curd, and green leafy vegetables",
        "Choose soft, easy-to-chew and digest foods",
        "Add turmeric and ginger for anti-inflammatory benefits",
        "Include fiber for digestive health (fruits, vegetables, whole grains)",
        "Eat smaller, more frequent meals if needed",
        "Ensure adequate Vitamin D through sunlight and supplements",
        "Reduce salt to support heart health and blood pressure",
      ],
    },
  };

  const currentPlan = plans[selectedPlan];
  const currentMeals = currentPlan.meals[dietPreference];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-green-500/10 via-blue-500/10 to-teal-500/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-teal-600 rounded-2xl mb-6">
              <Target className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl sm:text-5xl mb-6 text-gray-900">
              Personalized Indian Diet Plans
            </h1>
            <p className="text-lg sm:text-xl text-gray-600">
              Choose a diet plan tailored to your age, lifestyle, and dietary preferences
            </p>
          </div>
        </div>
      </section>

      {/* Plan Selection */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {(Object.keys(plans) as DietPlanType[]).map((planKey) => {
              const plan = plans[planKey];
              const isSelected = selectedPlan === planKey;
              return (
                <button
                  key={planKey}
                  onClick={() => setSelectedPlan(planKey)}
                  className={`text-left p-6 rounded-2xl transition-all ${
                    isSelected
                      ? "bg-white shadow-2xl scale-105 ring-2 ring-green-500"
                      : "bg-white/60 shadow-lg hover:shadow-xl hover:scale-102"
                  }`}
                >
                  <div className={`bg-gradient-to-br ${plan.color} w-14 h-14 rounded-xl flex items-center justify-center text-white mb-4`}>
                    {plan.icon}
                  </div>
                  <h3 className="text-xl mb-2 text-gray-900">{plan.title}</h3>
                  <p className="text-sm text-gray-600">{plan.subtitle}</p>
                  {isSelected && (
                    <div className="mt-4 flex items-center gap-2 text-green-600">
                      <CheckCircle2 className="w-5 h-5" />
                      <span className="text-sm">Selected</span>
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Dietary Preference Toggle */}
          <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-6 mb-12">
            <div className="flex items-center justify-between max-w-2xl mx-auto">
              <div className="flex items-center gap-3">
                <Leaf className="w-6 h-6 text-green-600" />
                <h3 className="text-lg text-gray-900">Choose Your Dietary Preference</h3>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setDietPreference("veg")}
                  className={`px-6 py-3 rounded-xl transition-all ${
                    dietPreference === "veg"
                      ? "bg-gradient-to-r from-green-600 to-teal-600 text-white shadow-lg"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  🌱 Vegetarian
                </button>
                <button
                  onClick={() => setDietPreference("nonveg")}
                  className={`px-6 py-3 rounded-xl transition-all ${
                    dietPreference === "nonveg"
                      ? "bg-gradient-to-r from-red-600 to-orange-600 text-white shadow-lg"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  🍗 Non-Vegetarian
                </button>
              </div>
            </div>
          </div>

          {/* Plan Details */}
          <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-2xl overflow-hidden">
            {/* Plan Header */}
            <div className={`bg-gradient-to-r ${currentPlan.color} p-8 text-white`}>
              <div className="max-w-5xl mx-auto">
                <div className="flex items-center gap-4 mb-4">
                  <div className="bg-white/20 backdrop-blur-sm p-4 rounded-xl">
                    {currentPlan.icon}
                  </div>
                  <div>
                    <h2 className="text-3xl mb-2">{currentPlan.title}</h2>
                    <p className="text-white/90">{currentPlan.subtitle}</p>
                  </div>
                </div>
                <p className="text-lg text-white/90 mb-6">{currentPlan.description}</p>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
                    <div className="text-sm text-white/80 mb-1">Daily Calories</div>
                    <div className="text-lg">{currentPlan.calories}</div>
                  </div>
                  {currentPlan.focus.slice(0, 3).map((item, index) => (
                    <div key={index} className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
                      <div className="text-sm text-white/80 mb-1">Focus</div>
                      <div className="text-lg">{item}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Meal Plan */}
            <div className="p-8">
              <div className="max-w-5xl mx-auto">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-3">
                    <Clock className="w-6 h-6 text-green-600" />
                    <h3 className="text-2xl text-gray-900">Daily Meal Schedule</h3>
                  </div>
                  <div className={`px-4 py-2 rounded-full ${
                    dietPreference === "veg" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                  }`}>
                    {dietPreference === "veg" ? "🌱 Vegetarian" : "🍗 Non-Vegetarian"}
                  </div>
                </div>

                <div className="space-y-6">
                  {Object.entries(currentMeals).map(([mealKey, meal]) => (
                    <div key={mealKey} className="bg-gray-50 rounded-2xl p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="text-xl text-gray-900 capitalize">
                          {mealKey.replace(/([A-Z])/g, " $1").trim()}
                        </h4>
                        <span className="text-sm text-gray-600 bg-white px-3 py-1 rounded-full">
                          {meal.time}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {meal.items.map((item, index) => (
                          <div key={index} className="flex items-start gap-2 text-gray-700">
                            <span className="text-green-500 mt-1">•</span>
                            <span>{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Tips Section */}
                <div className="mt-12 bg-gradient-to-br from-green-50 to-teal-50 rounded-2xl p-8">
                  <h4 className="text-xl text-gray-900 mb-6">Tips for Success</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {currentPlan.tips.map((tip, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-700">{tip}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Image */}
                <div className="mt-12">
                  <ImageWithFallback
                    src={currentPlan.image}
                    alt={currentPlan.title}
                    className="w-full h-[300px] object-cover rounded-2xl shadow-xl"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl p-8 text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-amber-100 rounded-full mb-4">
              <span className="text-2xl">⚠️</span>
            </div>
            <h3 className="text-xl text-gray-900 mb-3">Important Disclaimer</h3>
            <p className="text-gray-700 max-w-3xl mx-auto">
              These diet plans are general guidelines for educational purposes tailored to Indian dietary habits. 
              Individual nutritional needs vary based on health conditions, activity levels, and metabolism. Always consult 
              with a registered dietitian or healthcare provider before making significant dietary changes.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}