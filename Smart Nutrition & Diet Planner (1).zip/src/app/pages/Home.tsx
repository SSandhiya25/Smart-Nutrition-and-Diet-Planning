import { Link } from "react-router";
import { ArrowRight, Heart, Users, TrendingUp, BookOpen, Calculator, Utensils } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function Home() {
  const features = [
    {
      icon: <BookOpen className="w-6 h-6" />,
      title: "Nutrition Education",
      description: "Learn the fundamentals of healthy eating and balanced nutrition",
      link: "/nutrition-basics",
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Personalized Diet Plans",
      description: "Age and lifestyle-specific meal plans for students, professionals, and elderly",
      link: "/diet-plans",
    },
    {
      icon: <Calculator className="w-6 h-6" />,
      title: "BMI & Calorie Tools",
      description: "Calculate your BMI and daily calorie needs with our interactive tools",
      link: "/calculator",
    },
    {
      icon: <Utensils className="w-6 h-6" />,
      title: "Healthy Recipes",
      description: "Discover nutritious and delicious recipes for every meal",
      link: "/recipes",
    },
  ];

  const stats = [
    { value: "2000+", label: "Daily Calories Recommended" },
    { value: "5", label: "Servings of Fruits & Veggies" },
    { value: "8", label: "Glasses of Water Daily" },
    { value: "50%", label: "Whole Grains in Diet" },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 via-blue-500/10 to-teal-500/10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Text Content */}
            <div>
              <div className="inline-flex items-center gap-2 bg-green-100 px-4 py-2 rounded-full mb-6">
                <Heart className="w-4 h-4 text-green-600" />
                <span className="text-sm text-green-700">Your Health Companion</span>
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl mb-6 text-gray-900">
                Eat Smart, Live Healthy with{" "}
                <span className="bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent">
                  Smart Nutrition
                </span>
              </h1>
              
              <p className="text-lg sm:text-xl text-gray-600 mb-8">
                Discover personalized nutrition guidance tailored for Indian lifestyles, dietary preferences, 
                and health goals. Make informed decisions about what you eat and live healthier every day.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/calculator"
                  className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-green-600 to-teal-600 text-white px-8 py-4 rounded-xl hover:from-green-700 hover:to-teal-700 transition-all shadow-lg hover:shadow-xl"
                >
                  Calculate Your BMI
                  <ArrowRight className="w-5 h-5" />
                </Link>
                <Link
                  to="/nutrition-basics"
                  className="inline-flex items-center justify-center gap-2 bg-white text-gray-700 px-8 py-4 rounded-xl hover:bg-gray-50 transition-all border-2 border-gray-200"
                >
                  Learn More
                </Link>
              </div>
            </div>

            {/* Hero Image */}
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-green-500 to-teal-500 rounded-3xl blur-2xl opacity-20"></div>
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1568477070631-5bfef06fdf44?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwY29sb3JmdWwlMjB2ZWdldGFibGVzJTIwZnJ1aXRzfGVufDF8fHx8MTc3MDI2OTg1OHww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Fresh healthy vegetables and fruits"
                className="relative rounded-3xl shadow-2xl w-full h-[400px] object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="bg-white/80 backdrop-blur-md py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-teal-600 rounded-2xl mb-6">
              <TrendingUp className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-3xl sm:text-4xl mb-6 text-gray-900">
              Our Mission
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              At Smart Nutrition, we believe that everyone deserves access to reliable, 
              science-based nutritional information. Our mission is to empower individuals 
              of all ages and lifestyles to make informed dietary choices that promote 
              long-term health and wellness. Through personalized guidance, educational 
              resources, and practical tools, we're making healthy eating accessible to everyone.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="bg-white/80 backdrop-blur-md p-6 rounded-2xl shadow-lg">
                  <div className="text-3xl sm:text-4xl bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent mb-2">
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl mb-4 text-gray-900">
              Everything You Need for Better Nutrition
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Comprehensive tools and resources to help you understand and improve your eating habits
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <Link
                key={index}
                to={feature.link}
                className="group bg-white/80 backdrop-blur-md p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all hover:-translate-y-1"
              >
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-green-500 to-teal-600 rounded-xl flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                    {feature.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl mb-2 text-gray-900 group-hover:text-green-600 transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 mb-4">{feature.description}</p>
                    <div className="inline-flex items-center gap-2 text-green-600 group-hover:gap-3 transition-all">
                      <span className="text-sm">Explore</span>
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-green-600 to-teal-600 rounded-3xl p-12 text-center text-white shadow-2xl">
            <h2 className="text-3xl sm:text-4xl mb-4">
              Ready to Start Your Health Journey?
            </h2>
            <p className="text-lg text-green-50 mb-8 max-w-2xl mx-auto">
              Get personalized diet recommendations and track your nutrition goals today
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/diet-plans"
                className="inline-flex items-center justify-center gap-2 bg-white text-green-600 px-8 py-4 rounded-xl hover:bg-green-50 transition-all"
              >
                View Diet Plans
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center justify-center gap-2 bg-green-700 text-white px-8 py-4 rounded-xl hover:bg-green-800 transition-all"
              >
                Contact Expert
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}