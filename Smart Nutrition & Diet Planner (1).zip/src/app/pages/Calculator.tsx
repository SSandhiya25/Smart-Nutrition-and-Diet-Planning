import { useState } from "react";
import { Calculator as CalcIcon, Activity, Target, TrendingUp } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

type CalculatorType = "bmi" | "calorie";

export function Calculator() {
  const [activeCalculator, setActiveCalculator] = useState<CalculatorType>("bmi");

  // BMI Calculator State
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [bmiResult, setBmiResult] = useState<number | null>(null);

  // Calorie Calculator State
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("male");
  const [calorieHeight, setCalorieHeight] = useState("");
  const [calorieWeight, setCalorieWeight] = useState("");
  const [activityLevel, setActivityLevel] = useState("moderate");
  const [calorieResult, setCalorieResult] = useState<number | null>(null);

  const calculateBMI = () => {
    const heightInMeters = parseFloat(height) / 100;
    const weightInKg = parseFloat(weight);
    
    if (heightInMeters > 0 && weightInKg > 0) {
      const bmi = weightInKg / (heightInMeters * heightInMeters);
      setBmiResult(parseFloat(bmi.toFixed(1)));
    }
  };

  const calculateCalories = () => {
    const weightInKg = parseFloat(calorieWeight);
    const heightInCm = parseFloat(calorieHeight);
    const ageInYears = parseFloat(age);

    if (weightInKg > 0 && heightInCm > 0 && ageInYears > 0) {
      // Mifflin-St Jeor Equation
      let bmr;
      if (gender === "male") {
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageInYears + 5;
      } else {
        bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageInYears - 161;
      }

      // Activity multipliers
      const multipliers: { [key: string]: number } = {
        sedentary: 1.2,
        light: 1.375,
        moderate: 1.55,
        active: 1.725,
        veryActive: 1.9,
      };

      const tdee = bmr * multipliers[activityLevel];
      setCalorieResult(Math.round(tdee));
    }
  };

  const getBMICategory = (bmi: number) => {
    if (bmi < 18.5) return { category: "Underweight", color: "text-blue-600", bgColor: "bg-blue-50" };
    if (bmi < 25) return { category: "Normal", color: "text-green-600", bgColor: "bg-green-50" };
    if (bmi < 30) return { category: "Overweight", color: "text-orange-600", bgColor: "bg-orange-50" };
    return { category: "Obese", color: "text-red-600", bgColor: "bg-red-50" };
  };

  const getBMIRecommendation = (bmi: number) => {
    if (bmi < 18.5) {
      return "Consider increasing your caloric intake with nutrient-dense foods. Consult with a healthcare provider for personalized advice.";
    }
    if (bmi < 25) {
      return "Great! You're in a healthy weight range. Maintain your current lifestyle with balanced nutrition and regular exercise.";
    }
    if (bmi < 30) {
      return "Consider a balanced diet with portion control and regular physical activity. Small changes can make a big difference.";
    }
    return "It's important to consult with a healthcare provider for a personalized weight management plan focusing on nutrition and exercise.";
  };

  const getCalorieBreakdown = (calories: number) => {
    return [
      { name: "Carbs (45%)", value: Math.round(calories * 0.45 / 4), color: "#f59e0b" },
      { name: "Protein (25%)", value: Math.round(calories * 0.25 / 4), color: "#ef4444" },
      { name: "Fats (30%)", value: Math.round(calories * 0.30 / 9), color: "#eab308" },
    ];
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-green-500/10 via-blue-500/10 to-teal-500/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-teal-600 rounded-2xl mb-6">
              <CalcIcon className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl sm:text-5xl mb-6 text-gray-900">
              Health Calculators
            </h1>
            <p className="text-lg sm:text-xl text-gray-600">
              Calculate your BMI and daily calorie needs to make informed decisions about your health
            </p>
          </div>
        </div>
      </section>

      {/* Calculator Selection */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            <button
              onClick={() => setActiveCalculator("bmi")}
              className={`p-6 rounded-2xl transition-all ${
                activeCalculator === "bmi"
                  ? "bg-white shadow-2xl scale-105 ring-2 ring-green-500"
                  : "bg-white/60 shadow-lg hover:shadow-xl"
              }`}
            >
              <div className="flex items-center gap-4 mb-3">
                <div className="bg-gradient-to-br from-green-500 to-teal-600 w-12 h-12 rounded-xl flex items-center justify-center text-white">
                  <Activity className="w-6 h-6" />
                </div>
                <h3 className="text-xl text-gray-900">BMI Calculator</h3>
              </div>
              <p className="text-gray-600 text-left">
                Calculate your Body Mass Index to understand your weight category
              </p>
            </button>

            <button
              onClick={() => setActiveCalculator("calorie")}
              className={`p-6 rounded-2xl transition-all ${
                activeCalculator === "calorie"
                  ? "bg-white shadow-2xl scale-105 ring-2 ring-green-500"
                  : "bg-white/60 shadow-lg hover:shadow-xl"
              }`}
            >
              <div className="flex items-center gap-4 mb-3">
                <div className="bg-gradient-to-br from-blue-500 to-indigo-600 w-12 h-12 rounded-xl flex items-center justify-center text-white">
                  <Target className="w-6 h-6" />
                </div>
                <h3 className="text-xl text-gray-900">Calorie Calculator</h3>
              </div>
              <p className="text-gray-600 text-left">
                Determine your daily calorie needs based on your lifestyle
              </p>
            </button>
          </div>

          {/* BMI Calculator */}
          {activeCalculator === "bmi" && (
            <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-2xl p-8">
              <div className="flex items-center gap-3 mb-6">
                <Activity className="w-6 h-6 text-green-600" />
                <h2 className="text-2xl text-gray-900">BMI Calculator</h2>
              </div>

              <div className="space-y-6 mb-8">
                <div>
                  <label className="block text-gray-700 mb-2">Height (cm)</label>
                  <input
                    type="number"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                    placeholder="Enter your height in centimeters"
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-green-500 focus:outline-none transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-gray-700 mb-2">Weight (kg)</label>
                  <input
                    type="number"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    placeholder="Enter your weight in kilograms"
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-green-500 focus:outline-none transition-colors"
                  />
                </div>

                <button
                  onClick={calculateBMI}
                  className="w-full bg-gradient-to-r from-green-600 to-teal-600 text-white py-4 rounded-xl hover:from-green-700 hover:to-teal-700 transition-all shadow-lg hover:shadow-xl"
                >
                  Calculate BMI
                </button>
              </div>

              {bmiResult !== null && (
                <div className="space-y-6">
                  <div className={`${getBMICategory(bmiResult).bgColor} rounded-2xl p-8 text-center`}>
                    <div className="text-sm text-gray-600 mb-2">Your BMI</div>
                    <div className={`text-5xl mb-4 ${getBMICategory(bmiResult).color}`}>
                      {bmiResult}
                    </div>
                    <div className={`text-xl ${getBMICategory(bmiResult).color}`}>
                      {getBMICategory(bmiResult).category}
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-2xl p-6">
                    <h3 className="text-lg text-gray-900 mb-3">BMI Categories</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-700">Underweight</span>
                        <span className="text-blue-600">Below 18.5</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-700">Normal weight</span>
                        <span className="text-green-600">18.5 - 24.9</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-700">Overweight</span>
                        <span className="text-orange-600">25 - 29.9</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-700">Obese</span>
                        <span className="text-red-600">30 or above</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-green-50 to-teal-50 rounded-2xl p-6">
                    <div className="flex items-start gap-3">
                      <TrendingUp className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-lg text-gray-900 mb-2">Recommendation</h3>
                        <p className="text-gray-700">{getBMIRecommendation(bmiResult)}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Calorie Calculator */}
          {activeCalculator === "calorie" && (
            <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-2xl p-8">
              <div className="flex items-center gap-3 mb-6">
                <Target className="w-6 h-6 text-blue-600" />
                <h2 className="text-2xl text-gray-900">Daily Calorie Calculator</h2>
              </div>

              <div className="space-y-6 mb-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 mb-2">Age</label>
                    <input
                      type="number"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      placeholder="Enter your age"
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 mb-2">Gender</label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
                    >
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 mb-2">Height (cm)</label>
                    <input
                      type="number"
                      value={calorieHeight}
                      onChange={(e) => setCalorieHeight(e.target.value)}
                      placeholder="Enter your height"
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 mb-2">Weight (kg)</label>
                    <input
                      type="number"
                      value={calorieWeight}
                      onChange={(e) => setCalorieWeight(e.target.value)}
                      placeholder="Enter your weight"
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-gray-700 mb-2">Activity Level</label>
                  <select
                    value={activityLevel}
                    onChange={(e) => setActivityLevel(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
                  >
                    <option value="sedentary">Sedentary (little or no exercise)</option>
                    <option value="light">Light (exercise 1-3 times/week)</option>
                    <option value="moderate">Moderate (exercise 4-5 times/week)</option>
                    <option value="active">Active (daily exercise or intense 3-4 times/week)</option>
                    <option value="veryActive">Very Active (intense exercise 6-7 times/week)</option>
                  </select>
                </div>

                <button
                  onClick={calculateCalories}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-4 rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all shadow-lg hover:shadow-xl"
                >
                  Calculate Daily Calories
                </button>
              </div>

              {calorieResult !== null && (
                <div className="space-y-6">
                  <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-8 text-center">
                    <div className="text-sm text-gray-600 mb-2">Your Daily Calorie Needs</div>
                    <div className="text-5xl text-blue-600 mb-4">
                      {calorieResult}
                    </div>
                    <div className="text-xl text-gray-700">calories per day</div>
                  </div>

                  <div className="bg-gray-50 rounded-2xl p-6">
                    <h3 className="text-lg text-gray-900 mb-4 text-center">Recommended Macronutrient Distribution</h3>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={getCalorieBreakdown(calorieResult)}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, value }) => `${name.split(' ')[0]}: ${value}g`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {getCalorieBreakdown(calorieResult).map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white rounded-xl p-6 shadow-md">
                      <div className="text-sm text-gray-600 mb-2">Weight Loss</div>
                      <div className="text-2xl text-orange-600 mb-1">
                        {calorieResult - 500}
                      </div>
                      <div className="text-sm text-gray-600">cal/day (-500)</div>
                    </div>

                    <div className="bg-white rounded-xl p-6 shadow-md">
                      <div className="text-sm text-gray-600 mb-2">Maintenance</div>
                      <div className="text-2xl text-green-600 mb-1">
                        {calorieResult}
                      </div>
                      <div className="text-sm text-gray-600">cal/day</div>
                    </div>

                    <div className="bg-white rounded-xl p-6 shadow-md">
                      <div className="text-sm text-gray-600 mb-2">Weight Gain</div>
                      <div className="text-2xl text-blue-600 mb-1">
                        {calorieResult + 500}
                      </div>
                      <div className="text-sm text-gray-600">cal/day (+500)</div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6">
                    <h3 className="text-lg text-gray-900 mb-3">Important Notes</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2 text-gray-700">
                        <span className="text-blue-600 mt-1">•</span>
                        <span>These are estimates based on standard formulas and may vary for individuals</span>
                      </li>
                      <li className="flex items-start gap-2 text-gray-700">
                        <span className="text-blue-600 mt-1">•</span>
                        <span>For weight loss, aim for a gradual reduction of 0.5-1 kg per week</span>
                      </li>
                      <li className="flex items-start gap-2 text-gray-700">
                        <span className="text-blue-600 mt-1">•</span>
                        <span>Consult a healthcare professional for personalized nutrition advice</span>
                      </li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
